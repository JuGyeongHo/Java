import java.util.*;

public class JuGyeongHo {
    public static void main(String[] args) {
        /*
        Name : JuGyeongHo
        University : Handong Global University
        Student Number : 22100715
         */
        System.out.println("Name : JuGyeongHo");
        System.out.println("University : Handong Global University");
        System.out.println("Student Number : 22100715");
    }
}
